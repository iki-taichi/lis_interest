﻿using UnityEngine;
using System.Collections.Generic;

namespace MLPlayer {
	public class Action {
		public float rotate;
		public float forward;
		public float degInterest;
		public bool jump;
		public void Clear() {
			rotate = 0;
			forward = 0;
			degInterest = 0;
			jump = false;
		}

		public void Set(Dictionary<System.Object, System.Object> action) {
			Clear ();

			// make hash table (because the 2 data arrays with equal content do not provide the same hash)
			var decodedDict = new Dictionary<string, string>();
			foreach (byte[] key in action.Keys) {
				decodedDict.Add(
						System.Text.Encoding.UTF8.GetString(key),
					System.Text.Encoding.UTF8.GetString((byte[])action[key])
					);
				//Debug.Log ("key:" + System.Text.Encoding.UTF8.GetString(key) + " value:" + action[key]);
			}

			//int i = (int)action [originalKey ["command"]];
			//float f = float.Parse (System.Text.Encoding.UTF8.GetString((byte[])action [originalKey ["value"]]));
			degInterest = float.Parse(decodedDict ["degInterest"]);
			switch (decodedDict["command"]) {
			case "0":
				rotate = 1;
				break;
			case "1":
				rotate = -1;
				break;
			case "2":
				forward = 1;
				break;
			case "3":
				jump = true;
				break;
			}
		}
	}
}